
document.addEventListener('DOMContentLoaded', function(){
  const h1 = document.querySelector('main h1');
  if(h1) h1.setAttribute('tabindex', '-1');
});
